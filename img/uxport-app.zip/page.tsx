import DegradationDiagram from "./degradation-diagram"
import DegradationDiagramStatic from "./degradation-diagram-static"

export default function DiagramPage() {
  return (
    <div className="min-h-screen bg-gray-100 py-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-12">Metodología de Diseño: Degradación Progresiva</h1>

        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-4 text-center">Diagrama Interactivo</h2>
          <DegradationDiagram />
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4 text-center">Diagrama Estático (para exportar como imagen)</h2>
          <DegradationDiagramStatic />
        </div>
      </div>
    </div>
  )
}
