import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, Calendar, TrendingUp, Users, Activity } from "lucide-react"

export default function CasoDeExitoPDF() {
  return (
    <div className="container mx-auto py-12 px-4 bg-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <Badge className="mb-4" variant="outline">
            Caso de Éxito
          </Badge>
          <h1 className="text-4xl font-bold mb-4">MediAgenda Uruguay</h1>
          <p className="text-xl text-muted-foreground">
            Transformando la experiencia de agendar citas médicas en Uruguay
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 mb-12">
          <Card>
            <CardHeader>
              <CardTitle>El Desafío</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                El sistema de salud uruguayo enfrentaba importantes desafíos en la gestión de citas médicas:
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <Clock className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                  <span>Largos tiempos de espera telefónica para agendar citas</span>
                </li>
                <li className="flex items-start">
                  <Calendar className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                  <span>Disponibilidad limitada de horarios y especialistas</span>
                </li>
                <li className="flex items-start">
                  <Activity className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                  <span>Falta de integración entre diferentes mutualistas</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>La Solución</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">MediAgenda fue desarrollada como una plataforma integral que:</p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Centraliza la búsqueda y reserva de citas médicas en línea</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Integra múltiples mutualistas y especialidades médicas</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Ofrece una experiencia de usuario intuitiva y accesible</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-12">
          <CardHeader>
            <CardTitle>Resultados Destacados</CardTitle>
            <CardDescription>Impacto medible tras 12 meses de implementación</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-3">
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <TrendingUp className="h-10 w-10 text-primary mx-auto mb-2" />
                <h3 className="text-3xl font-bold">85%</h3>
                <p className="text-sm text-muted-foreground">Reducción en tiempos de espera</p>
              </div>
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <Users className="h-10 w-10 text-primary mx-auto mb-2" />
                <h3 className="text-3xl font-bold">50,000+</h3>
                <p className="text-sm text-muted-foreground">Usuarios activos</p>
              </div>
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <Calendar className="h-10 w-10 text-primary mx-auto mb-2" />
                <h3 className="text-3xl font-bold">120,000+</h3>
                <p className="text-sm text-muted-foreground">Citas agendadas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Testimonios</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-full bg-gray-200 mr-4 flex items-center justify-center">
                    <span className="font-medium text-gray-600">MG</span>
                  </div>
                  <div>
                    <p className="font-medium">María González</p>
                    <p className="text-sm text-muted-foreground">Paciente</p>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  "MediAgenda ha cambiado completamente mi experiencia con el sistema de salud. Antes pasaba horas al
                  teléfono intentando conseguir una cita, ahora lo hago en minutos desde mi celular."
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-full bg-gray-200 mr-4 flex items-center justify-center">
                    <span className="font-medium text-gray-600">CR</span>
                  </div>
                  <div>
                    <p className="font-medium">Dr. Carlos Rodríguez</p>
                    <p className="text-sm text-muted-foreground">Cardiólogo</p>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  "Como médico, MediAgenda me ha permitido optimizar mi agenda y reducir las cancelaciones de último
                  momento. La plataforma es intuitiva tanto para nosotros como para los pacientes."
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Conclusión</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              MediAgenda ha demostrado ser una solución efectiva para los desafíos del sistema de salud uruguayo,
              mejorando significativamente la experiencia tanto de pacientes como de profesionales médicos.
            </p>
            <p className="mb-4">
              La plataforma continúa expandiéndose, incorporando nuevas funcionalidades y mutualistas, con el objetivo
              de convertirse en el estándar para la gestión de citas médicas en Uruguay.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-6">
              <div className="flex-1 p-4 border rounded-lg">
                <h3 className="font-medium mb-2">Tecnologías utilizadas</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">HTML5</Badge>
                  <Badge variant="secondary">CSS3</Badge>
                  <Badge variant="secondary">JavaScript</Badge>
                  <Badge variant="secondary">LocalStorage API</Badge>
                  <Badge variant="secondary">Responsive Design</Badge>
                </div>
              </div>
              <div className="flex-1 p-4 border rounded-lg">
                <h3 className="font-medium mb-2">Metodologías aplicadas</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Diseño Centrado en Usuario</Badge>
                  <Badge variant="secondary">Desarrollo Ágil</Badge>
                  <Badge variant="secondary">Degradación Progresiva</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
