import { ArrowRight, Monitor, Tablet, Smartphone, Check, ArrowDown } from "lucide-react"

export default function DegradationDiagramStatic() {
  const steps = [
    {
      title: "Diseño para Escritorio",
      description: "Desarrollo completo de la experiencia en pantallas grandes",
      icon: Monitor,
      color: "bg-blue-500",
    },
    {
      title: "Adaptación para Tablets",
      description: "Reorganización de elementos manteniendo funcionalidades",
      icon: Tablet,
      color: "bg-indigo-500",
    },
    {
      title: "Optimización para Móviles",
      description: "Simplificación de la interfaz priorizando contenido esencial",
      icon: Smartphone,
      color: "bg-purple-500",
    },
  ]

  const benefits = [
    "Diseño completo desde el inicio",
    "Mantenimiento de funcionalidades clave",
    "Adaptación progresiva a cada dispositivo",
    "Experiencia coherente en todas las plataformas",
  ]

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-md">
      <h2 className="text-2xl font-bold text-center mb-8">Enfoque de Degradación Progresiva</h2>

      <div className="flex flex-col items-center mb-12">
        <div className="flex flex-col md:flex-row items-center justify-between w-full mb-8">
          {steps.map((step, index) => (
            <div key={index} className="relative flex flex-col items-center mb-8 md:mb-0">
              <div className={`${step.color} text-white p-4 rounded-full mb-4`}>
                <step.icon size={32} />
              </div>
              <h3 className="text-lg font-semibold text-center mb-2">{step.title}</h3>
              <p className="text-sm text-center text-gray-600 max-w-xs">{step.description}</p>

              {index < steps.length - 1 && (
                <div className="hidden md:block absolute left-full top-1/2 transform -translate-y-1/2 w-12 text-gray-400">
                  <ArrowRight size={24} />
                </div>
              )}
              {index < steps.length - 1 && (
                <div className="block md:hidden absolute top-full left-1/2 transform -translate-x-1/2 h-8 text-gray-400">
                  <ArrowDown size={24} />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="w-full p-5 bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="text-lg font-semibold mb-4 text-center">Beneficios del Enfoque</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <Check className="h-5 w-5 text-green-500" />
                </div>
                <p className="ml-2 text-gray-700">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="relative">
        <div className="flex flex-col md:flex-row justify-between items-center bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-100">
          <div className="flex-1 p-4">
            <h4 className="font-semibold text-lg mb-2 text-center">Diseño Inicial</h4>
            <div className="bg-white border-2 border-blue-500 rounded-md h-32 flex items-center justify-center relative">
              <div className="w-3/4 h-4 bg-gray-300 rounded mb-2"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-xs text-gray-500">
                Versión Escritorio
              </div>
            </div>
          </div>

          <ArrowRight className="hidden md:block text-gray-400 mx-2" />
          <ArrowDown className="block md:hidden text-gray-400 my-2" />

          <div className="flex-1 p-4">
            <h4 className="font-semibold text-lg mb-2 text-center">Adaptación</h4>
            <div className="bg-white border-2 border-indigo-500 rounded-md h-32 w-3/4 mx-auto flex items-center justify-center relative">
              <div className="w-3/4 h-4 bg-gray-300 rounded mb-2"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-xs text-gray-500">
                Versión Tablet
              </div>
            </div>
          </div>

          <ArrowRight className="hidden md:block text-gray-400 mx-2" />
          <ArrowDown className="block md:hidden text-gray-400 my-2" />

          <div className="flex-1 p-4">
            <h4 className="font-semibold text-lg mb-2 text-center">Optimización</h4>
            <div className="bg-white border-2 border-purple-500 rounded-md h-32 w-1/2 mx-auto flex items-center justify-center relative">
              <div className="w-3/4 h-4 bg-gray-300 rounded mb-2"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-xs text-gray-500">
                Versión Móvil
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-sm text-gray-600">
          <p>
            A diferencia del enfoque "mobile-first", la degradación progresiva comienza con la experiencia más completa
            (escritorio) y luego adapta para dispositivos más pequeños.
          </p>
        </div>
      </div>
    </div>
  )
}
