import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function DiagramaPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-8">
          <Link href="/">
            <Button variant="outline">← Volver al inicio</Button>
          </Link>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Diagrama de Flujo de MediAgenda</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg p-4 overflow-auto">
                {/* Aquí iría el diagrama de mermaid renderizado */}
                <div className="text-center text-sm text-muted-foreground mb-4">
                  Diagrama de flujo de la aplicación MediAgenda
                </div>

                <pre className="bg-gray-50 p-4 rounded-lg overflow-auto text-xs">
                  {`graph TD;
    A["Página de Inicio"] --> B["Búsqueda de Médicos"]
    A --> C["Iniciar Sesión"]
    A --> D["Registro"]
    
    B --> E["Resultados de Búsqueda"]
    E --> F["Perfil del Médico"]
    F --> G["Agendar Cita"]
    
    C --> H["Perfil de Usuario"]
    D --> H
    
    H --> I["Mis Consultas"]
    H --> J["Historial Médico"]
    H --> K["Configuración"]
    
    G --> L{{"¿Usuario Logueado?"}}
    L -->|No| C
    L -->|Sí| M["Confirmación de Cita"]
    M --> I
    
    I --> N["Detalle de Consulta"]
    N --> O["Cancelar Consulta"]
    N --> P["Reprogramar Consulta"]`}
                </pre>
              </div>

              <div className="mt-8">
                <h3 className="text-lg font-medium mb-4">Descripción del Flujo</h3>
                <p className="mb-4">
                  El diagrama muestra el recorrido completo del usuario a través de la plataforma MediAgenda, desde la
                  página de inicio hasta la gestión de citas médicas.
                </p>

                <div className="space-y-4 mt-6">
                  <div>
                    <h4 className="font-medium">Flujo Principal:</h4>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>
                        El usuario inicia en la página principal donde puede buscar médicos, iniciar sesión o
                        registrarse
                      </li>
                      <li>
                        La búsqueda de médicos lleva a resultados filtrados y luego al perfil detallado del médico
                      </li>
                      <li>Desde el perfil del médico, el usuario puede agendar una cita</li>
                      <li>El proceso de agendamiento requiere autenticación y confirmación</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium">Área de Usuario:</h4>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>
                        El perfil de usuario permite acceder a consultas agendadas, historial médico y configuración
                      </li>
                      <li>Las consultas pueden ser visualizadas en detalle, canceladas o reprogramadas</li>
                      <li>El historial médico mantiene un registro de todas las consultas pasadas</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
