import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"

export default function DiagramaPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-8">
          <Link href="/">
            <Button variant="outline">← Volver al inicio</Button>
          </Link>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Diagrama de Flujo de MediAgenda</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative w-full h-[600px] border rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Diagrama de flujo de MediAgenda"
                  fill
                  className="object-contain"
                />
              </div>

              <div className="mt-8">
                <h3 className="text-lg font-medium mb-4">Descripción del Flujo</h3>
                <p className="mb-4">
                  El diagrama muestra el recorrido completo del usuario a través de la plataforma MediAgenda, desde la
                  página de inicio hasta la gestión de citas médicas.
                </p>

                <div className="space-y-4 mt-6">
                  <div>
                    <h4 className="font-medium">Flujo Principal:</h4>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>
                        El usuario inicia en la página principal donde puede buscar médicos, iniciar sesión o
                        registrarse
                      </li>
                      <li>
                        La búsqueda de médicos lleva a resultados filtrados y luego al perfil detallado del médico
                      </li>
                      <li>Desde el perfil del médico, el usuario puede agendar una cita</li>
                      <li>El proceso de agendamiento requiere autenticación y confirmación</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium">Área de Usuario:</h4>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>
                        El perfil de usuario permite acceder a consultas agendadas, historial médico y configuración
                      </li>
                      <li>Las consultas pueden ser visualizadas en detalle, canceladas o reprogramadas</li>
                      <li>El historial médico mantiene un registro de todas las consultas pasadas</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
