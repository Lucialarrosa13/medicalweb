import CasoDeExito from "../../caso-de-exito"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { FileDown } from "lucide-react"

export default function CasoDeExitoPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-8">
          <Link href="/">
            <Button variant="outline">← Volver al inicio</Button>
          </Link>
          <Link href="/caso-de-exito/pdf">
            <Button>
              <FileDown className="mr-2 h-4 w-4" />
              Versión para imprimir
            </Button>
          </Link>
        </div>

        <CasoDeExito />
      </div>
    </div>
  )
}
