import CasoDeExitoPDF from "../../../caso-de-exito-pdf"

export default function CasoDeExitoPDFPage() {
  return <CasoDeExitoPDF />
}
