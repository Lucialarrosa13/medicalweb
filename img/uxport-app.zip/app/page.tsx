import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, BarChart2 } from "lucide-react"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Portfolio de Proyecto MediAgenda</h1>
          <p className="text-xl text-muted-foreground">
            Documentación y recursos del proyecto de plataforma de citas médicas para Uruguay
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="mr-2 h-5 w-5" />
                Caso de Éxito
              </CardTitle>
              <CardDescription>Análisis detallado del impacto y resultados del proyecto</CardDescription>
            </CardHeader>
            <CardContent>
              <p>
                Documento que presenta el desafío abordado, la solución implementada y los resultados obtenidos con
                MediAgenda.
              </p>
            </CardContent>
            <CardFooter>
              <Link href="/caso-de-exito" className="w-full">
                <Button className="w-full">Ver Caso de Éxito</Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart2 className="mr-2 h-5 w-5" />
                Diagrama de Flujo
              </CardTitle>
              <CardDescription>Visualización de la estructura y navegación de la aplicación</CardDescription>
            </CardHeader>
            <CardContent>
              <p>
                Diagrama que muestra el flujo de usuario a través de las diferentes secciones y funcionalidades de
                MediAgenda.
              </p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Link href="/diagrama" className="w-full">
                <Button className="w-full">Ver Diagrama</Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    </main>
  )
}
