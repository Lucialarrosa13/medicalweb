[V0_FILE]tsx:file="estudio-usabilidad.tsx"
'use client'

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function EstudioUsabilidad() {
  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6">Estudio de Usabilidad: Hallazgos</h1>
      
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Introducción al Estudio</CardTitle>
          <CardDescription>Metodología y objetivos</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-base">
            Realizamos un estudio de usabilidad en dos rondas con un total de 12 participantes (6 en cada ronda) para evaluar la interfaz de reserva de citas médicas. Los participantes, con edades entre 25-65 años, completaron tareas específicas mientras verbalizaban sus pensamientos. El objetivo fue identificar problemas de usabilidad y áreas de mejora en la experiencia de usuario antes del lanzamiento final.
          </p>
        </CardContent>
      </Card>
      
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="bg-blue-50 dark:bg-blue-950">
            <CardTitle className="text-blue-600 dark:text-blue-300">Hallazgos de la Ronda 1</CardTitle>
            <CardDescription>Primera iteración de pruebas</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">1</div>
                <div>
                  <h3 className="font-medium">Dificultad para localizar información del médico</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    El 70% de los usuarios tardaron más de 30 segundos en encontrar las credenciales educativas del médico, sugiriendo problemas de jerarquía visual.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">2</div>
                <div>
                  <h3 className="font-medium">Confusión con el calendario de citas</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Los usuarios no entendían inicialmente que debían seleccionar primero una fecha antes de ver las horas disponibles, causando frustración y clics innecesarios.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">3</div>
                <div>
                  <h3 className="font-medium">Falta de confirmación visual</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Los usuarios no recibían retroalimentación clara después de seleccionar una hora, generando incertidumbre sobre si la selección se había registrado correctamente.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="bg-purple-50 dark:bg-purple-950">
            <CardTitle className="text-purple-600 dark:text-purple-300">Hallazgos de la Ronda 2</CardTitle>
            <CardDescription>Segunda iteración después de mejoras</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold">1</div>
                <div>
                  <h3 className="font-medium">Mejora en la navegación</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Después de rediseñar la jerarquía visual, el 90% de los usuarios encontraron la información del médico en menos de 15 segundos, representando una mejora significativa.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold">2</div>
                <div>
                  <h3 className="font-medium">Proceso de reserva más intuitivo</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    La implementación de indicadores visuales para guiar el flujo de selección fecha-hora redujo el tiempo de reserva en un 40%.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold">3</div>
                <div>
                  <h3 className="font-medium">Preocupaciones sobre precios</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Aunque la información de precios era visible, el 50% de los usuarios expresaron que les gustaría ver opciones de pago o seguros aceptados antes de confirmar la cita.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-8">
        <Tabs defaultValue="metricas">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="metricas">Métricas Clave</TabsTrigger>
            <TabsTrigger value="recomendaciones">Recomendaciones</TabsTrigger>
            <TabsTrigger value="siguientes-pasos">Siguientes Pasos</TabsTrigger>
          </TabsList>
          <TabsContent value="metricas" className="p-4 border rounded-md mt-2">
            <ul className="list-disc pl-5 space-y-2">
              <li><strong>Tasa de éxito:</strong> Aumentó del 65% en la Ronda 1 al 92% en la Ronda 2</li>
              <li><strong>Tiempo promedio de tarea:</strong> Disminuyó de 2:45 minutos a 1:20 minutos</li>
              <li><strong>Satisfacción del usuario (SUS):</strong> Mejoró de 68/100 a 84/100</li>
              <li><strong>Tasa de error:</strong> Disminuyó de 3.5 errores por usuario a 0.8 errores por usuario</li>
            </ul>
          </TabsContent>
          <TabsContent value="recomendaciones" className="p-4 border rounded-md mt-2">
            <ul className="list-disc pl-5 space-y-2">
              <li>Implementar un indicador de progreso para mostrar en qué paso del proceso de reserva se encuentra el usuario</li>
              <li>Añadir información sobre métodos de pago y seguros aceptados junto al precio de la consulta</li>
              <li>Mejorar el contraste de color en los botones de acción principal para usuarios con visión reducida</li>
              <li>Incluir un resumen de la cita antes de la confirmación final para verificación</li>
            </ul>
          </TabsContent>
          <TabsContent value="siguientes-pasos" className="p-4 border rounded-md mt-2">
            <ul className="list-disc pl-5 space-y-2">
              <li>Implementar las recomendaciones prioritarias antes del lanzamiento</li>
              <li>Realizar pruebas de accesibilidad con usuarios que utilizan tecnologías de asistencia</li>
              <li>Desarrollar un plan para recopilar feedback post-lanzamiento</li>
              <li>Programar una tercera ronda de pruebas después de 3 meses de uso real para evaluar la experiencia a largo plazo</li>
            </ul>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}